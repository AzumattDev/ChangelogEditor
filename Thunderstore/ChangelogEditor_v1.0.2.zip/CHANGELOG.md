| `Version` | `Update Notes`                                                      |
|-----------|---------------------------------------------------------------------|
| 1.0.2     | - ErDu's request to add in option to change the ChangLog title text |
| 1.0.1     | - Toggle correctly                                                  |
| 1.0.0     | - Initial Release                                                   |